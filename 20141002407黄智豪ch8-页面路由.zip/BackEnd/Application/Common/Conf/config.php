<?php
return array(
	//'配置项'=>'配置值'
	'DB_TYPE'	=> 'mysql',
	'DB_HOST'	=> 'localhost',
	'DB_NAME'	=> 'music',	// 数据库名
	'DB_USER'	=> 'root',	// 用户名
	'DB_PWD'	=> '',		// 密码
	'DB_PORT'	=> 3306,	// 端口
	'DB_PREFIX'	=> 'app_'	// 数据库表前缀 
);
define ( function ( require ) {
	require('../common/cookie');
	var $ = require('jquery');
	var Reg = require('./reg');
	var R = new Reg();
	R.render();
});
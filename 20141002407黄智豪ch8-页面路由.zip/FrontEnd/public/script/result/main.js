define(function(require) {
	require('../common/cookie');
	var $ = require('jquery');

	var Result = require('./result');
	Result.render();
});
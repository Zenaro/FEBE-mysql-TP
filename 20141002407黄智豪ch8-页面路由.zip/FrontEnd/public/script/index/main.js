define(function(require) {
	var $ = require('jquery');
	require('../common/cookie');
	var Index = require('./index');
	var i = new Index();
	i.render();
});




